#include <stdlib.h>
#include <stdio.h>

#include "othello.h"

#define DEPTH 4

int GoodAITurn(Board *b, int color)
{
  // Put your code for minimax here
  return 0;
}